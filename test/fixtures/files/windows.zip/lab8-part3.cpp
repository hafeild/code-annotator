//============================================================================== 
// File name    : lab8-part3.cpp
// Author       : 
// Date         : 
// Description  : 
// Collaborators: 
//==============================================================================
#include <iostream>
// For file IO.
#include <fstream>
using namespace std;

 
struct Contact {
    string name, address, phoneNumber;
};
 
int getFileSize(string filename);
void printArray(Contact *array, int size);
 
int main()
{
    int size;
    string filename;
    ifstream fileIn;
 
    // Create a dynamic array to hold the instances of the Contact struct.
    Contact *contacts;

    // Read the filename in from the user.
    cout << "Please enter a filename: ";
    cin >> filename;
 
    // Get the file size of that file and allocate memory for the array.
    // Keep in mind: the number of lines is 3x the number of entries we
    // need for our array.
    size = getFileSize(filename) / 3;
    contacts = new Contact[size];
 
    // Open the input file.
    fileIn.open(filename.c_str());

    // Read in each of the entries from the file, create a new Contact
    // instance, and store it in the array. Remember that there are
    // three lines for each contact.
    for(int i = 0; i < size; i++)
    {
        getline(fileIn, contacts[i].name);
        getline(fileIn, contacts[i].address);
        getline(fileIn, contacts[i].phoneNumber);
    }

    // Close the file.
    fileIn.close();

    // Print the array.
    printArray(contacts, size);

    return 0;
}
 
/**
 * Reads in the entire file specified by filename to figure out how many
 * lines it contains.
 *
 * @param filename The name of the file.
 * @return The number of lines contained in the file.
 */
int getFileSize(string filename) 
{
    int size = 0;
    string curLine;
    ifstream fileIn;
 
    // Open the file.
    fileIn.open(filename.c_str());
 
    // Read in all of the lines, keeping track of how many lines we've seen.
    while(fileIn.good())
    {
        getline(fileIn, curLine);
        size++;
    }
 
    // Close the file.
    fileIn.close();
 
    return size;
}
 
/**
 * Prints an array to stdout.
 *
 * @param array The array to print.
 * @param size The size of the array.
 */
void printArray(Contact *array, int size) 
{
    for(int i = 0; i < size; i++)
        cout << (i+1) << ": " << array[i].name << " ("
             << array[i].phoneNumber << ")" << endl;
}
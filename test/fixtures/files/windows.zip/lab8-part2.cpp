#include <iostream>
// For file IO.
#include <fstream>
using namespace std;

int getFileSize(string filename);
void printArray(string *array, int size);

int main()
{
    int size;
    string filename;

    // Create a dynamic array to hold the names from the input file.
    string *names;

    // Read the filename in from the user.
    cout << "Please enter the file to read: ";
    cin >> filename;

    // Get the file size of that file and allocate memory for the array.
    size = getFileSize(filename);
    names = new string[size];

    // Open the input file.
    ifstream fileIn;
    fileIn.open(filename.c_str());

    // Read in the first five lines of the input file into the array.
    for(int i = 0; i < size; i++)
        getline(fileIn, names[i]);

    // Close the file.
    fileIn.close();

    // Print the array.
    printArray(names, size);

    return 0;
}

/**
 * Reads in the entire file specified by filename to figure out how many
 * lines it contains.
 *
 * @param filename The name of the file.
 * @return The number of lines contained in the file.
 */
int getFileSize(string filename) 
{
    int size = 0;
    string curLine;
    ifstream fileIn;

    // Open the file.
    fileIn.open(filename.c_str());

    // Read in all of the lines, keeping track of how many lines we've seen.
    while(fileIn.good())
    {
        getline(fileIn, curLine);
        size++;
    }

    // Close the file.
    fileIn.close();

    return size;
}

/**
 * Prints an array to stdout.
 *
 * @param array The array to print.
 * @param size The size of the array.
 */
void printArray(string *array, int size) 
{
    for(int i = 0; i < size; i++)
        cout << (i+1) << ": " << array[i] << endl;
}